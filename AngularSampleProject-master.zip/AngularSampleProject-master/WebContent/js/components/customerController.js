angular.module("appController").directive('myformat', function(dateFilter) {
  return {
		require: 'ngModel',
		link: function(scope, element, attrs, ngModel) {
  		ngModel.$parsers.push(function(viewValue) {
       	return dateFilter(viewValue, 'yyyy-MM-dd');
			});
		}
	}
});


angular.module("appController").controller("customerController", function ($scope, $rootScope, $http,appModel,DTOptionsBuilder,DTColumnBuilder) {
	
    $scope.selectedType=$scope.selectedYear=$scope.selectedMonth= "Select";
    $scope.filteredType = $scope.filteredYear=$scope.filteredMonth="";
    $scope.isHidden=false;
    $scope.loader=false;
    $scope.year=new Array();
    $scope.month=new Array();
    $scope.dtOptions = DTOptionsBuilder.newOptions()
//    .withPaginationType('simple')
    .withDisplayLength(100)
    
    .withDOM("<'row custom_row'<'col-sm-12'l>><'row'<'col-sm-12'tr>>" +
    		"<'row'<'col-sm-10'i><'col-sm-2'p>>")
    .withColumnFilter({
    	sPlaceHolder: "head:after",
            aoColumns: [{
                type: 'text'
            }, {
                type: 'text',
                bRegex: true,
                bSmart: true
            },{
                type: 'text',
                bRegex: true,
                bSmart: true
            },{
                type: 'text',
                bRegex: true,
                bSmart: true
            },{
                type: 'text',
                bRegex: true,
                bSmart: true
            },{
                type: 'text',
                bRegex: true,
                bSmart: true
            },{
                type: 'text',
                bRegex: true,
                bSmart: true
            },{
                type: 'text',
                bRegex: true,
                bSmart: true
            } ]
   });
    
   
//    $scope.dtColumns = [
//                    DTColumnBuilder.newColumn('envCd').withTitle('Environment'),
//                    DTColumnBuilder.newColumn('managerName').withTitle('Manager Name'),
//                    DTColumnBuilder.newColumn('Person Id').withTitle('Person Id'),
//                    DTColumnBuilder.newColumn('Username').withTitle('Username'),
//                    DTColumnBuilder.newColumn('Role').withTitle('Role'),
//                    DTColumnBuilder.newColumn('Approve').withTitle('Approve'),
//                    DTColumnBuilder.newColumn('Revoke').withTitle('Revoke'),
//                    DTColumnBuilder.newColumn('Not Reviewed').withTitle('Not Reviewed')
//                ];
    $scope.loadData=function(){
    	$scope.loader=true;
    	console.log($scope.loader);
            $scope.params={
                type:($scope.selectedType!=="Select")?$scope.selectedType:'',
                year:($scope.selectedYear!=="Select")?$scope.selectedYear:'',
                month:($scope.selectedMonth!=="Select")?$scope.selectedMonth:''
            };
            appModel.getData($scope.params).then(function(response){ 
                console.log(response);
                if(response.listOfModels.length>0){
                	
                	$scope.isHidden=true;
                }else{
                	$scope.isHidden=false;
                }
                $scope.auditData = response.listOfModels;    
                $scope.loader=false;
                
            });
            //	
        
    }
    $scope.getDropdown=function(config){
    	$scope.loader=true;
      appModel.getDropdownData().then(function(response){ 
                $scope.dropdownData = response.listOfModels;
                if($scope.dropdownData.length>0){
                	$scope.dropdownData.forEach(function(element,index){
                        if ($scope.year.indexOf(element.ctrlYear) == -1) 
                        {
                            $scope.year.push(element.ctrlYear)
                        }
                        if(element.activeInd==="Y"){
                    		$scope.setTypeAction(element.ctrlName);
                    		$scope.setYearAction(element.ctrlYear);
                    		$scope.setMonthAction(element.ctrlDateRange);
                    	}
                    });
                    $scope.loader=false;
                    $scope.loadData();
                }
                
                console.log($scope.year);
                
            });
        
    }
    
    $scope.setTypeAction = function (option) {
        //customerObj.add({fname:$scope.fname,lname:$scope.lname,phone:$scope.phone,email:$scope.email,address:$scope.address});
        $scope.filteredType=$scope.selectedType = option;
    }
    $scope.setYearAction = function (option) {
        console.log(option);
        //customerObj.add({fname:$scope.fname,lname:$scope.lname,phone:$scope.phone,email:$scope.email,address:$scope.address});
        $scope.filteredYear=$scope.selectedYear = option;
        $scope.changeMonthAction();
    }
    $scope.setMonthAction = function (option) {
        //customerObj.add({fname:$scope.fname,lname:$scope.lname,phone:$scope.phone,email:$scope.email,address:$scope.address});
        $scope.filteredMonth=$scope.selectedMonth = option;
    }
    $scope.changeMonthAction = function(){
        $scope.month=[];
        console.log("changeMonthAction");
        if($scope.selectedyear!=="Select"){
            $scope.dropdownData.forEach(function(element,index){
                    if ($scope.month.indexOf(element.ctrlDateRange) == -1 && element.ctrlYear===$scope.selectedYear ) 
                    {
                        $scope.month.push(element.ctrlDateRange);
                    }
                });
        }
        
    }
    $scope.exportAction = function(){
    	
    }
    $scope.getDropdown();
    $scope.today = new Date().toGMTString();
});

