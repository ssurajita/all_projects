angular.module("appController",['ui.bootstrap','datatables','datatables.columnfilter']);

