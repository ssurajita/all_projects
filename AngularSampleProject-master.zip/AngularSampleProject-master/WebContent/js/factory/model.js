angular.module("appController").factory('appModel', function ($http) {

    
    var obj = {};
    obj.getData = function(params){
    	
        var Indata = {
        		params:{ctrlName: params.type, ctrlYear: params.year ,ctrlMonth:params.month}
        };
        console.log("request param",Indata);
        return $http.get(CONTEXT_PATH+"/json/auditInfo.json",Indata).then(function(response) {
                return response.data;
            });
    };
    obj.getDropdownData = function(){
        return $http.get(CONTEXT_PATH+"/json/auditDropdown.json").then(function(response) {
                return response.data;
            });
    };
    return obj;
});

