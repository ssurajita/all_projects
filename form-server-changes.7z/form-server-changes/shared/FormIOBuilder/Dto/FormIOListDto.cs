﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace NavigateCloud.FormIOBuilder.Dto
{

    public class GetForms
    {
        public string Filter { get; set; }
    }

    public class FormIOListDto : Abp.Application.Services.Dto.FullAuditedEntityDto
    {
        public int FormId { get; set; }

        public string FormName { get; set; }

        public string FormString { get; set; }

    }

    public class CreateFormIOListInput
    {
        //[Required]
        //[MaxLength(FormIOListConsts.MaxFormIdLength)]
        public int FormId { get; set; }

        //[Required]
        [MaxLength(FormIOListConsts.MaxFormNameLength)]
        public string FormName { get; set; }

        [MaxLength(FormIOListConsts.MaxFormStringLength)]
        public string FormString { get; set; }
    }

    public class FormIOListConsts
    {
        public const int MaxFormIdLength = 32;
        public const int MaxFormNameLength = 500;
        public const int MaxFormStringLength = 10000;
    }

}
