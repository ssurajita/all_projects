customerApp.controller("customerController", function($scope,getAddress) {
   $scope.customer = {
      firstName: "Soumya",
      lastName: "Surajita",
      balance:500
   };
   
   $scope.custAddress = getAddress;
});