carModule.filter('cc',function(){
	return function(ccValue) {
		return ccValue + ' C.C';
	}
	
});