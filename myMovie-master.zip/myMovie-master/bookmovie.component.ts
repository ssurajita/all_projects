import {Component} from '@angular/core';
import { HttpModule } from '@angular/http';

@Component({
  selector: 'bookmovie',
  styleUrls: ['./bookmovie.component.css'],
  templateUrl: './bookmovie.component.html'
})
export class BookMovieComponent {
	movie_name = "Padmabat";
	movie_price = "Rs." + 270;
	movie_slots = ["9AM","12PM","3PM","6PM","9PM",];
	movie_seats =[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,
21,22,23,24,25,26,27,28,29,30,
31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,5,56,57,58,59,60];

  	public pickSeat(event, item) {
 	   confirm('You are choosing seat number: ' + item);

 	   selected_seat = item;
  	}

  	public pickSlot(event, item) {
 	   confirm('You are choosing slot number: ' + item);
 	   selected_slot = item;
  	}

  	public booknow(event){
  		if(selected_seat !== empty){
  			console.log(selected_seat,selected_slotmovie_name,movie_slots,movie_seats)
  		}
  	}
	constructor(){
	}
}
