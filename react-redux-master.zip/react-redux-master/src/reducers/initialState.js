export default {
  authors: [],
  vehicles: [],
  ajaxCallsInProgress: 0
};
