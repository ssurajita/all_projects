https://www.pluralsight.com/courses/react-redux-react-router-es6

FYI: This course is *awesome*. Cory explains things exceptionally well, and it is a wonderful code-along experience.
