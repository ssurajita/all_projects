﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using Abp.Collections.Extensions;
using Abp.Domain.Repositories;
using Abp.Extensions;
using NavigateCloud.FormIOBuilder.Dto;

namespace NavigateCloud.FormIOBuilder
{
    public class FormIOListService : NavigateCloudAppServiceBase, NavigateCloud.FormIOBuilder.IFormIOListService
    {
        //public ListResultDto<FormIOListDto> GetForms(GetForms input)
        //{
        //    throw new NotImplementedException();
        //}


        private readonly Abp.Domain.Repositories.IRepository<FormIOList> _formRepository;

        public FormIOListService(IRepository<FormIOList> formRepository)
        {
            _formRepository = formRepository;
        }
        public ListResultDto<FormIOListDto> GetForms(GetForms input)
        {
            var form = _formRepository
                .GetAll()
                //.WhereIf(
                //    !input.Filter.IsNullOrEmpty(),
                //    p => 
                //         p.FormName.Contains(input.Filter) ||
                //         p.FormString.Contains(input.Filter)
                //)
                //.OrderBy(p => p.FormName)
                //.ThenBy(p => p.FormName)
                .ToList();

            return new ListResultDto<FormIOListDto>(ObjectMapper.Map<List<FormIOListDto>>(form));
        }

       
        //public async Task CreateForms(CreateFormsInput input)
        //{
        //    //var form = ObjectMapper.Map<FormIOList>(input);
        //    FormIOList objData = new FormIOList();
        //    objData.FormId = input.FormId;
        //    objData.FormName = input.FormName;
        //    objData.FormString = input.FormString;

        //    await _formRepository.InsertAsync(objData);
        //    //await _formRepository.InsertAsync(form);
        //}

        public async Task CreateFormIOList(CreateFormIOListInput input)
        {
            var formData = ObjectMapper.Map<FormIOList>(input);
            await _formRepository.InsertAsync(formData);
        }


        public async Task CreateFormBuilder(CreateFormIOListInput input)
        {
            FormIOList objPerson = new FormIOList();
            objPerson.FormId = input.FormId;
            objPerson.FormName = input.FormName;
            objPerson.FormString = input.FormString;
            await _formRepository.InsertAsync(objPerson);
        }


    }
}
