using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;

namespace NavigateCloud.FormIOBuilder
{
    [Table("PbFormIOList")]
    public class FormIOList : FullAuditedEntity
    {
        public const int MaxFormIdIdLength = 32;
        public const int MaxFormNameLength = 32;
        public const int MaxFormStringLength = 255;

        [Required]
        [MaxLength(MaxFormIdIdLength)]
        public virtual int FormId { get; set; }

        [Required]
        [MaxLength(MaxFormNameLength)]
        public virtual string FormName { get; set; }

        [MaxLength(MaxFormStringLength)]
        public virtual string FormString { get; set; }
    }
}