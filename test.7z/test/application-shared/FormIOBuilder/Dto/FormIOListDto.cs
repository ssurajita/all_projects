﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NavigateCloud.FormIOBuilder.Dto
{

    public class GetForms
    {
        public string Filter { get; set; }
    }

    public class FormIOListDto : Abp.Application.Services.Dto.FullAuditedEntityDto
    {
        public int FormId { get; set; }

        public string FormString { get; set; }

    }


}
