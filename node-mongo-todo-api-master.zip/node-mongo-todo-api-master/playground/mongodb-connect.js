//const MongoClient = require('mongodb').MongoClient;
// const {MongoClient} = require('mongodb'); we achieve above statement using destructuring
const {MongoClient,ObjectID} = require('mongodb');
var obj = new ObjectID();
console.log(obj);

// MongoClient.connect('mongodb://localhost:27017/TodoApp', (err,client) => {
MongoClient.connect('mongodb://localhost:27017/TodoApp', (err,db) => {
  if(err){
    return console.log('Unable to connect to mongoDB server');
  }
  console.log('Connected to mongoDB server');
  //db = client.db('TodoApp');
  // db.collection('Todos').insertOne({
  //   text : 'Something to do... here',
  //   completed : false
  // }, (err,result) => {
  //   if(err){
  //     return console.log('Unable to insert todo', err);
  //   }
  //   console.log(JSON.stringify(result.ops, undefined, 2));
  // });

  db.collection('Users').insertOne({
    name : 'Soumya',
    age : 29,
    location : 'Bangalore'
  }, (err,result) => {
    if(err){
      return console.log('Unable to insert Users', err);
    }
    console.log(JSON.stringify(result.ops, undefined, 2));
    console.log(JSON.stringify(result.ops[0]._id.getTimestamp(), undefined, 2));

  });
  db.close();
  //client.close();

});
