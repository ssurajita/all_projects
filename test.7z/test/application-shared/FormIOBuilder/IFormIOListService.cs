﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using NavigateCloud.FormIOBuilder.Dto;
using System;
using System.Collections.Generic;
using System.Text;

namespace NavigateCloud.FormIOBuilder
{
    public interface IFormIOListService : IApplicationService
    {

        ListResultDto<FormIOListDto> GetForms(GetForms input);
    }
}
