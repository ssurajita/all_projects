# AngularBasicExample
This is a sample dynamic web project built using Angular 1.x demonstrating a datatable populating data based on the filter dropdown selection.

----------

## Technology Stack

> - UI Layer
>	 - [Angular 1.x](https://angularjs.org/)
> - Service Layer
>	 - NA
> - Database Layer
>  - NA

----------

## Requirements

> - Java >= 1.7
> - Eclipse >= 3.0.0
> - Tomcat > 7
> - git

----------

## Complete Installation Guide

Clone this repository in the local machine.
```
git clone https://github.com/ssurajita/AngularSampleProject.git

```
Import the project in eclipse.

New > Import > General > Existing Projects into Workspace

Include Tomcat in the server settings of the eclipse.

Run the project in the tomcat.

----------

## Core Team

> - <a href="mailto:ssurajita111@gmail.com">Soumya Surajita</a>

For any concerns, please contact the developer.

