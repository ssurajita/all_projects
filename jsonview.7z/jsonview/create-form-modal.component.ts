import { Component, ViewChild, Injector, ElementRef, Output, EventEmitter } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap';
import { CreateFormIOListInput } from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/common/app-component-base';
import { finalize } from 'rxjs/operators';
import { FormIOListServiceServiceProxy, FormIOListDto, ListResultDtoOfFormIOListDto } from '@shared/service-proxies/service-proxies';

@Component({
    selector: 'createFormModal',
    templateUrl: './create-form-modal.component.html'
})
export class CreateFormModalComponent extends AppComponentBase {

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    @ViewChild('modal') modal: ModalDirective;
    @ViewChild('nameInput') nameInput: ElementRef;

    form: CreateFormIOListInput = new CreateFormIOListInput();

    active: boolean = false;
    saving: boolean = false;

    constructor(
        injector: Injector,
        private _formIOService: FormIOListServiceServiceProxy
    ) {
        super(injector);
    }

    show(): void {
        this.active = true;
        this.form = new CreateFormIOListInput();
        this.modal.show();
    }

    onShown(): void {
        this.nameInput.nativeElement.focus();
    }

    save(): void {
        this.saving = true;
        this._formIOService.createFormIOList(this.form)
            .pipe(finalize(() => this.saving = false))
            .subscribe(() => {
                this.notify.info(this.l('SavedSuccessfully'));
                this.close();
                this.modalSave.emit(this.form);
            });
    }

    close(): void {
        this.modal.hide();
        this.active = false;
    }
}