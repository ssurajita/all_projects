import { Component, OnInit ,Injector} from '@angular/core';
import { AppComponentBase } from '@shared/common/app-component-base';
import { appModuleAnimation } from '@shared/animations/routerTransition';
import { FormIOListServiceServiceProxy, FormIOListDto, ListResultDtoOfFormIOListDto } from '@shared/service-proxies/service-proxies';
import { FormioForm } from 'angular-formio'; 
import {FormioFormImpl} from './FormioFormImpl';

@Component({
  selector: 'app-jsonview',
  templateUrl: './jsonview.component.html',
  styleUrls: ['./jsonview.component.css'],
  animations: [appModuleAnimation()]
})
export class JsonviewComponent extends AppComponentBase implements OnInit {
  formData: FormIOListDto[] = [];
  filter: string = '';
  static : string = '';
  htmlObject ;
  public form: FormioForm = {
    components: []
  }; 

  constructor(
    injector: Injector,
    private _personService: FormIOListServiceServiceProxy) {
    super(injector);
}

  ngOnInit(): void {
    this.getForms();
  }
  
  formTest : any;
  loadForm(formData): void{
    console.log(formData, " ***************** ");
    this.formTest = JSON.parse(formData.formString);

  }
  getForms(): void {
    this._personService.getForms(this.filter).subscribe((result) => {
        this.formData = result.items;
        var formioObj = new FormioFormImpl();
        // this.formTest = {
        //   components: [{
        //   "label": "Checkbox",
        //   "shortcut": "",
        //   "mask": false,
        //   "tableView": true,
        //   "alwaysEnabled": false,
        //   "type": "checkbox",
        //   "input": true,
        //   "key": "checkbox2",
        //   "defaultValue": false,
        //   "validate": {
        //     "customMessage": "",
        //     "json": ""
        //   },
        //   "conditional": {
        //     "show": "",
        //     "when": "",
        //     "json": ""
        //   },
        //   "reorder": false,
        //   "encrypted": false,
        //   "properties": {},
        //   "customConditional": "",
        //   "logic": []
        // }, {
        //   "type": "button",
        //   "label": "Submit",
        //   "key": "submit",
        //   "disableOnInvalid": true,
        //   "theme": "primary",
        //   "input": true,
        //   "tableView": true
        // }]
        // }
        this.formTest = JSON.parse(result.items[7].formString);
        console.log('formTestObj',this.formTest);
        console.log('formTestObjType',typeof(this.formTest));
                Object.assign(formioObj, {
          components: result.items[7]
        }); 
        this.form = formioObj;

        console.log(result.items[7], this.form, "***Data***");

      //   console.log(result.items[0].formString,"result.items[0].formString")
      //  // this.form = result;
      //   this.static = `<formio [form] = \' ${result.items[5].formString} \'></formio>` ;
      
      //   this.htmlObject = document.createElement(this.static);
      //   var doc = new DOMParser().parseFromString(this.static, "text/xml");
      //   console.log(this.htmlObject,"****");
      //   document.getElementById("formio-div").innerHTML = this.htmlObject;

    });
  }
}
