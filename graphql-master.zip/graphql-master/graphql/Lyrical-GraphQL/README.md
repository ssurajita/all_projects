# Lyrical-GraphQL

Starter project from a GraphQL course on Udemy.com

# react app connect to graphql server using ApolloProvider, and ApolloStore

# ApolloStore

Apollo Store is what is going to communicate directly with graphql server and store store data that comes back from it.
This is a store of data that exists at client side of ouur application.
The apollo store is a client side repository of all the data that is coming from the graphql server.
And in this course we are going to talk about a lot whats going on inside of that server.
This is an abstract piece of technology.
This is something that does not care about what client side framework we are using for showing data on the screen
So Apollo Store it has no idea intrinsively that react exists. It does not care.

# ApolloProvider

The integration layer between the apollo store and our actual react application is the Apollo Provider.
So its a provider of data for our react application
The provider will take data from the store and inject it into our react application
So it is the glue layer between the apollo store and our actual react application.

# ApolloClient

This actually interacts with the graphql server on the backend.
It is actually making request for data and storing the data locally when the response comes back
This has no idea that we are using react or any other technology
import {AppleClient} 'apollo-client'

# ApolloProvider

import {ApolloProvider} 'react-apollo'

# UI components we are going to create

SongList
SongDetail
LyricList
LyricCreate

# graphql queries or mutations are not valid javascript code.

So to use it inside react components we should import a library called graphql-tag
And we need to use gql with backtick ``.

gql is actually defining the query not executing it..
const query = gql`{ songs { title } }`;

# bond query and component together

//Using graphql
import { graphql } from 'react-apollo';

# Note

new ApolloClient({}) assumes that graphql server is available on '/graphql' route.
So there is some kind of assumptions made by the ApolloClient

# fix "message": "Unknown modifier: \$pushAll.

# server/models/song.js

{
usePushEach: true,
}

## addSong mutation

# input

mutation {
addSong(title : "Cold Night"){
id
}
}

# output

{
"data": {
"addSong": {
"id": "5ee372d6d2d4ba1545e7f002"
}
}
}

## addLyricToSong

# input

mutation {
addLyricToSong(songId : "5ee372d6d2d4ba1545e7f002" , content: "oh my oh my its a cold night"){
id
}
}

# output

{
"data": {
"addLyricToSong": {
"id": "5ee372d6d2d4ba1545e7f002"
}
}
}

## songs query

# input

query {
songs{
id
title
lyrics{
content
}
}
}

# output

{
"data": {
"songs": [
{
"id": "5ee372d6d2d4ba1545e7f002",
"title": "Cold Night",
"lyrics": [
{
"content": "oh my oh my its a cold night"
}
]
}
]
}
}

# gql

gql is to create query at client side within a component file

# import { graphql } from 'react-apollo'; => works like connect()

This is used to bind a component and query together..
export default graphql(query)(SongList);

# mutation query variables => for arguments to send to server

# input

mutation AddSong($title : String){
	addSong(title : $title){
id
title
}
}

//query variables
{
"title" : "Balam Pichkari"
}

# output

{
"data": {
"addSong": {
"id": "5ee3c188d2d4ba1545e7f00a",
"title": "Balam Pichkari"
}
}
}

const mutation = gql`mutation AddUser($title: String) { addSong(title: $title) { id title } }`;

//inside component method we can access the mutatio like this
onSubmit(event) {
event.preventDefault();
this.props.mutate({
variables: {
title: this.state.title,
},
});
}

# Note : props.mutate we recieve in case of mutation inside a component

# Note : props.data we recieve in case of query inside a component

# addLyrictoSong

# input

mutation AddLyricToSong($content : String, $songId : ID){
addLyricToSong(songId :$songId, content : $content){
id
lyrics{
content
}
}
}

{
"songId" : "5ee372d6d2d4ba1545e7f002",
"content" : "It was a long night"
}

# output

{
"data": {
"addLyricToSong": {
"id": "5ee372d6d2d4ba1545e7f002",
"lyrics": [
{
"content": "oh my oh my its a cold night"
},
{
"content": "oh my oh my its a cold night"
},
{
"content": "It was a long night"
}
]
}
}
}

# LyricList

# input

query SongQuery($id: ID!) {
    song(id: $id) {
id
title
lyrics{
id
content
}
}
}

{
"id" : "5ee372d6d2d4ba1545e7f002"
}

# output

{
"data": {
"song": {
"id": "5ee372d6d2d4ba1545e7f002",
"title": "Cold Night",
"lyrics": [
{
"id": "5ee37320d2d4ba1545e7f003",
"content": "oh my oh my its a cold night"
},
{
"id": "5ee373f4d2d4ba1545e7f004",
"content": "oh my oh my its a cold night"
},
{
"id": "5ee4742dc0d38b2317828ce1",
"content": "It was a long night"
},
{
"id": "5ee47654c0d38b2317828ce2",
"content": "Night to remember"
},
{
"id": "5ee476fcc0d38b2317828ce3",
"content": "Moon was bright"
},
{
"id": "5ee476fec0d38b2317828ce4",
"content": "Moon was bright"
},
{
"id": "5ee47711c0d38b2317828ce5",
"content": "Moon was dim"
}
]
}
}
}

# http://dev.apollodata.com/react/cache-updates.html
