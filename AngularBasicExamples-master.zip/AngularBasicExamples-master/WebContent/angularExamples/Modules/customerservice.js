customerApp.factory('getAddress', function() {
		return {
				return "Inorbit Hyderbad";
		};
});