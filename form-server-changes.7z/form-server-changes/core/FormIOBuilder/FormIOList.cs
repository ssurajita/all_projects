using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Abp.Domain.Entities.Auditing;

namespace NavigateCloud.FormIOBuilder
{
    [Table("PbFormIOList")]
    public class FormIOList : FullAuditedEntity
    {
        public const int MaxFormIdLength = 32;
        public const int MaxFormNameLength = 500;
        public const int MaxFormStringLength = 10000;

        [Required]
        [MaxLength(MaxFormIdLength)]
        public virtual int FormId { get; set; }

        [Required]
        [MaxLength(MaxFormNameLength)]
        public virtual string FormName { get; set; }

        [MaxLength(MaxFormStringLength)]
        public virtual string FormString { get; set; }
    }
}