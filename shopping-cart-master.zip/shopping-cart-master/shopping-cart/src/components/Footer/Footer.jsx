import "./Footer.css";
import React from "react";

function template() {
  return (
    <div className="footer">
    </div>
  );
};

export default template;
