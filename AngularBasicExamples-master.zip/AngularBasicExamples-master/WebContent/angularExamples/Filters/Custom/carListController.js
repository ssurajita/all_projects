carModule.controller("carDetailsController", function($scope,ccFilter) {
   $scope.carlist = [
		{
		  brand: "BMW",
		  name : "X3",
		  cc: "3000",
		  price:100000
		},
		{
		  brand: "Audi",
		  name : "A3",
		  cc: "2890",
		  price:980000
		},
		{
		  brand: "Maruthi",
		  name : "Alto",
		  cc: "899",
		  price:23000
		}
   ];
   
   $scope.someVar = true;
   
   $scope.callMe = function(){
	   console.log('I am called by Submit Button');	   
   };
   
   var result = ccFilter(1000);
   console.log("The cc is: " + result);
});