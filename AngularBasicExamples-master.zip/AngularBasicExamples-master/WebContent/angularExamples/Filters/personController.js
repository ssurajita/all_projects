function personController($scope) {
    $scope.technologies = [
        {name:'C++',type:'OOPS'},
        {name:'Java',type:'OOPS'},
        {name:'C',type:'LINEAR'},
		{name:'AngularJS',type:'OOPS'}
    ];
    $scope.lastName = "Surajita";
}