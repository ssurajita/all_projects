const {MongoClient,ObjectID} = require('mongodb');

MongoClient.connect('mongodb://localhost:27017/TodoApp', (err,db) => {
  if(err){
    return console.log('Unable to connect to mongoDB server');
  }
  console.log('Connected to mongoDB server');

  //delete Many
  // db.collection('Todos').deleteMany({text : 'Eat lunch'}).then( (result) => {
  //   console.log(result);
  // })

  //delete one
  // db.collection('Todos').deleteOne({text : 'Eat lunch'}).then( (result) => {
  //   console.log(result);
  // })

  //find one and delete
  // db.collection('Todos').findOneAndDelete({completed : false}).then( (result) => {
  //   console.log(result);
  // })


//Task..delete many that has same name and then delete one any one by its id..
  db.collection('Users').deleteMany({name : 'Soumya'}).then( (result) => {
    console.log(result);
  })

  db.collection('Users').deleteOne({_id : new ObjectID('5ac749894cbae70443e747f3') }).then( (result) => {
    console.log(JSON.stringify(result, undefined, 2));
  })

  //db.close();

});
