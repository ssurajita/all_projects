﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Abp.Application.Services.Dto;
using Abp.Collections.Extensions;
using Abp.Domain.Repositories;
using Abp.Extensions;
using NavigateCloud.FormIOBuilder.Dto;

namespace NavigateCloud.FormIOBuilder
{
    class FormIOListService : NavigateCloudAppServiceBase, IFormIOListService
    {
        //public ListResultDto<FormIOListDto> GetForms(GetForms input)
        //{
        //    throw new NotImplementedException();
        //}


        private readonly Abp.Domain.Repositories.IRepository<FormIOList> _formRepository;

        public FormIOListService(IRepository<FormIOList> formRepository)
        {
            _formRepository = formRepository;
        }
        public ListResultDto<FormIOListDto> GetForms(GetForms input)
        {
            var form = _formRepository
                .GetAll()
                //.WhereIf(
                //    !input.Filter.IsNullOrEmpty(),
                //    p => 
                //         p.FormName.Contains(input.Filter) ||
                //         p.FormString.Contains(input.Filter)
                //)
                //.OrderBy(p => p.FormName)
                //.ThenBy(p => p.FormName)
                .ToList();

            return new ListResultDto<FormIOListDto>(ObjectMapper.Map<List<FormIOListDto>>(form));
        }
    }
}
